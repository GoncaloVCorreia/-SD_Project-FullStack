Correr código sem javadoc

1. Instalar docker desktop
2. Abrir pasta code copy no Visual Studio 
3. Abrir num container
4. Após container estar a correr abrir um novo terminal JavaScript Debug terminal
5. Mudar para a diretoria demoJPA+webservices
6. executar o comando ./mvnw spring-boot:run